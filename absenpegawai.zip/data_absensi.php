<?php
require_once 'config/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['jabatan'] != 'Administrator') {
    header('Location: index.php');
    exit;
}

// Ambil parameter filter
$filter_tanggal = $_GET['tanggal'] ?? '';
$filter_nama = $_GET['nama'] ?? '';
$filter_status = $_GET['status'] ?? '';

// Build query dengan filter
$where = [];
$params = [];

if ($filter_tanggal) {
    $where[] = 'a.tanggal = ?';
    $params[] = $filter_tanggal;
}

if ($filter_nama) {
    $where[] = 'p.nama LIKE ?';
    $params[] = '%' . $filter_nama . '%';
}

if ($filter_status) {
    $where[] = 'a.status = ?';
    $params[] = $filter_status;
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Query data absensi
$stmt = $pdo->prepare("
    SELECT a.*, p.nama, p.nip, p.jabatan 
    FROM absensi a 
    JOIN pegawai p ON a.id_pegawai = p.id_pegawai 
    $where_clause 
    ORDER BY a.tanggal DESC, a.jam_masuk DESC
");
$stmt->execute($params);
$absensi = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Absensi - Kecamatan Ajibarang</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://unpkg.com/feather-icons"></script>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Header -->
    <header class="bg-[#F9B000] text-white shadow-lg">
        <div class="container mx-auto px-4 py-4">
            <div class="flex justify-between items-center">
                <div class="flex items-center space-x-4">
                    <img src="assets/logo.png" alt="Logo" class="w-12 h-12">
                    <div>
                        <h1 class="text-xl font-bold">Sistem Absensi</h1>
                        <p class="text-white/90 text-sm">Kecamatan Ajibarang</p>
                    </div>
                </div>
                <div class="text-right">
                    <p class="font-semibold"><?= htmlspecialchars($_SESSION['user']['nama']) ?></p>
                    <p class="text-white/80 text-sm">Administrator</p>
                </div>
            </div>
        </div>
    </header>

    <!-- Navigation -->
    <nav class="bg-[#1F9D55] text-white shadow-md">
        <div class="container mx-auto px-4">
            <div class="flex space-x-8">
                <a href="dashboard.php" class="py-3 px-2 hover:bg-[#188a4a] transition duration-200 flex items-center space-x-2">
                    <i data-feather="home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="absen.php" class="py-3 px-2 hover:bg-[#188a4a] transition duration-200 flex items-center space-x-2">
                    <i data-feather="clock"></i>
                    <span>Absensi</span>
                </a>
                <a href="data_absensi.php" class="py-3 px-2 border-b-2 border-white font-semibold flex items-center space-x-2">
                    <i data-feather="file-text"></i>
                    <span>Data Absensi</span>
                </a>
                <a href="logout.php" class="py-3 px-2 hover:bg-[#188a4a] transition duration-200 flex items-center space-x-2 ml-auto">
                    <i data-feather="log-out"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <h2 class="text-2xl font-bold text-gray-800 mb-2">Data Absensi Pegawai</h2>
            <p class="text-gray-600">Kelola dan pantau data absensi seluruh pegawai.</p>
        </div>

        <!-- Filter Section -->
        <div class="bg-white rounded-2xl shadow-lg p-6 mb-8">
            <h3 class="text-xl font-bold text-gray-800 mb-4">Filter Data</h3>
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <label for="tanggal" class="block text-sm font-medium text-gray-700 mb-2">Tanggal</label>
                    <input type="date" id="tanggal" name="tanggal" value="<?= htmlspecialchars($filter_tanggal) ?>" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F9B000]">
                </div>
                <div>
                    <label for="nama" class="block text-sm font-medium text-gray-700 mb-2">Nama Pegawai</label>
                    <input type="text" id="nama" name="nama" value="<?= htmlspecialchars($filter_nama) ?>" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F9B000]">
                </div>
                <div>
                    <label for="status" class="block text-sm font-medium text-gray-700 mb-2">Status</label>
                    <select id="status" name="status" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#F9B000]">
                        <option value="">Semua Status</option>
                        <option value="hadir" <?= $filter_status == 'hadir' ? 'selected' : '' ?>>Hadir</option>
                        <option value="izin" <?= $filter_status == 'izin' ? 'selected' : '' ?>>Izin</option>
                        <option value="sakit" <?= $filter_status == 'sakit' ? 'selected' : '' ?>>Sakit</option>
                        <option value="dinas luar" <?= $filter_status == 'dinas luar' ? 'selected' : '' ?>>Dinas Luar</option>
                    </select>
                </div>
                <div class="flex items-end">
                    <button type="submit" 
                            class="w-full bg-[#F9B000] hover:bg-[#e6a000] text-white font-bold py-2 px-4 rounded-lg transition duration-200">
                        Terapkan Filter
                    </button>
                </div>
            </form>
        </div>

        <!-- Action Buttons -->
        <div class="flex justify-between items-center mb-6">
            <h3 class="text-xl font-bold text-gray-800">Data Absensi</h3>
            <div class="flex space-x-4">
                <a href="exports/export_excel.php?<?= http_build_query($_GET) ?>" 
                   class="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200 flex items-center space-x-2">
                    <i data-feather="download"></i>
                    <span>Export Excel</span>
                </a>
                <button onclick="window.print()" 
                        class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200 flex items-center space-x-2">
                    <i data-feather="printer"></i>
                    <span>Cetak Laporan</span>
                </button>
            </div>
        </div>

        <!-- Data Table -->
        <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full table-auto">
                    <thead>
                        <tr class="bg-gray-50">
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">No</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Tanggal</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Nama</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">NIP</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Jabatan</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Jam Masuk</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Jam Keluar</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Status</th>
                            <th class="px-6 py-4 text-left text-sm font-semibold text-gray-700">Lokasi</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-200">
                        <?php if (empty($absensi)): ?>
                            <tr>
                                <td colspan="9" class="px-6 py-8 text-center text-gray-500">
                                    <i data-feather="inbox" class="w-12 h-12 mx-auto text-gray-400 mb-2"></i>
                                    <p>Tidak ada data absensi</p>
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; ?>
                            <?php foreach ($absensi as $absen): ?>
                            <tr class="hover:bg-gray-50 transition duration-150">
                                <td class="px-6 py-4 text-sm text-gray-900"><?= $no++ ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?= htmlspecialchars($absen['tanggal']) ?></td>
                                <td class="px-6 py-4 text-sm font-medium text-gray-900"><?= htmlspecialchars($absen['nama']) ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?= htmlspecialchars($absen['nip']) ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?= htmlspecialchars($absen['jabatan']) ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?= $absen['jam_masuk'] ? htmlspecialchars($absen['jam_masuk']) : '-' ?></td>
                                <td class="px-6 py-4 text-sm text-gray-900"><?= $absen['jam_keluar'] ? htmlspecialchars($absen['jam_keluar']) : '-' ?></td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex px-3 py-1 rounded-full text-xs font-semibold 
                                        <?= $absen['status'] == 'hadir' ? 'bg-green-100 text-green-800' : 
                                           ($absen['status'] == 'izin' ? 'bg-yellow-100 text-yellow-800' : 
                                           ($absen['status'] == 'sakit' ? 'bg-red-100 text-red-800' : 'bg-blue-100 text-blue-800')) ?>">
                                        <?= strtoupper($absen['status']) ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php if ($absen['lokasi_lat'] && $absen['lokasi_lng']): ?>
                                        <a href="https://maps.google.com/?q=<?= $absen['lokasi_lat'] ?>,<?= $absen['lokasi_lng'] ?>" 
                                           target="_blank" 
                                           class="text-blue-600 hover:text-blue-800 flex items-center space-x-1">
                                            <i data-feather="map-pin" class="w-4 h-4"></i>
                                            <span>Lihat</span>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-gray-400">-</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <script>
        feather.replace();
    </script>
</body>
</html>