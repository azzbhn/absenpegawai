<?php
require_once '../config/db.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['jabatan'] != 'Administrator') {
    header('Location: ../index.php');
    exit;
}

// Ambil parameter filter
$filter_tanggal = $_GET['tanggal'] ?? '';
$filter_nama = $_GET['nama'] ?? '';
$filter_status = $_GET['status'] ?? '';

// Build query dengan filter
$where = [];
$params = [];

if ($filter_tanggal) {
    $where[] = 'a.tanggal = ?';
    $params[] = $filter_tanggal;
}

if ($filter_nama) {
    $where[] = 'p.nama LIKE ?';
    $params[] = '%' . $filter_nama . '%';
}

if ($filter_status) {
    $where[] = 'a.status = ?';
    $params[] = $filter_status;
}

$where_clause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

// Query data absensi
$stmt = $pdo->prepare("
    SELECT a.*, p.nama, p.nip, p.jabatan 
    FROM absensi a 
    JOIN pegawai p ON a.id_pegawai = p.id_pegawai 
    $where_clause 
    ORDER BY a.tanggal DESC, a.jam_masuk DESC
");
$stmt->execute($params);
$absensi = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header untuk download file Excel
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="data_absensi_' . date('Y-m-d') . '.xls"');

echo "Data Absensi Pegawai Kecamatan Ajibarang\n";
echo "Tanggal Export: " . date('d/m/Y H:i:s') . "\n\n";

echo "No\tTanggal\tNama\tNIP\tJabatan\tJam Masuk\tJam Keluar\tStatus\n";

$no = 1;
foreach ($absensi as $absen) {
    echo $no++ . "\t";
    echo $absen['tanggal'] . "\t";
    echo $absen['nama'] . "\t";
    echo $absen['nip'] . "\t";
    echo $absen['jabatan'] . "\t";
    echo $absen['jam_masuk'] . "\t";
    echo $absen['jam_keluar'] . "\t";
    echo $absen['status'] . "\n";
}